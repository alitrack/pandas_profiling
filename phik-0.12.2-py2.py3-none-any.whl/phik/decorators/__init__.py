# flake8: noqa

# import pandas DataFrame decorators
from phik.decorators import pandas
